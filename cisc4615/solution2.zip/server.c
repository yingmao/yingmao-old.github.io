// Lab 1
// Data Communications and Networks
// Dr. Mao

/*
Compilation Instructions
________________________

1. gcc server.c -o server
2. gcc client.c -o client

Run Instructions
________________
1. ./server
2. ./client 127.0.0.1
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MYPORT 1088  // the port users will be connecting to
#define BACKLOG 5    // how many pending connections queue will hold
#define BUF_SIZE 200 // the buffer size
int fd_A[BACKLOG];   // accepted connection fd
int conn_amount;     // current connection amount

void showclient()
{
    printf("Client amount: %d\n", conn_amount);
    for (int i = 0; i < BACKLOG; i++)
    {
        printf("[%d]:%d  ", i, fd_A[i]);
    }
    printf("\n\n");
}

// A Message structure that contains a sender, receiver and message
struct Message
{
    int sender;
    int receiver;
    char *message;
};

// Displays all the messages ever sent (not required for the lab, just for debugging purposes)
void displayAllMessages(int numberOfMessages, struct Message allMessages[])
{
    for (int i = 0; i < numberOfMessages; i++)
    {
        printf("%i. From: %i, To: %i, %s\n", i + 1, allMessages[i].sender, allMessages[i].receiver, allMessages[i].message);
    }
}

// Lists the active socket IDs
void listCommand(char buf_list[], int *j, int *i)
{
    strcpy(buf_list, "The active IDs are --- ");
    for (*j = 0; *j < conn_amount; (*j)++)
        if (fd_A[*j] != 0)
        {
            char c[4];
            sprintf(c, "%d\t", fd_A[*j]);
            strcat(buf_list, c);
        }
    strcat(buf_list, "\nEND\n");
    send(fd_A[*i], buf_list, strlen(buf_list), 0);
}

// Messages another active socket
void msgCommand(char buf_list[], char clientInput[], struct Message allMessages[], int *numberOfMessages, int i)
{
    strtok(clientInput, " "); // remove the "msg" portion of the request

    // Grab the client number
    char *clientNumber;
    clientNumber = strtok(NULL, " ");
    const int msgRecipient = atoi(clientNumber);

    // Grab the message
    char *message;
    message = strtok(NULL, "");
    message = strtok(message, "\n");

    // Send the message to the specified socket
    send(msgRecipient, message, strlen(message), 0);

    // Instantiate a message struct and store it
    struct Message msg = {fd_A[i], msgRecipient, strdup(message)};
    allMessages[*numberOfMessages] = msg;
    (*numberOfMessages)++; // Increment the number of messages

    strcat(buf_list, "\nEND");

    send(fd_A[i], buf_list, strlen(buf_list), 0);
}

// historyCommand() Helper Function
// Returns a character array of all the messages between a specified sender and receiver
char *chatHistory(int senderOrReceiver1, int senderOrReceiver2, int numberOfMessages, struct Message allMessages[])
{
    static char messages[1024];
    char interpolatedString[100];
    int numMessages = 0;
    for (int i = 0; i < numberOfMessages; i++)
    {
        if ((senderOrReceiver1 == allMessages[i].sender && senderOrReceiver2 == allMessages[i].receiver) || (senderOrReceiver2 == allMessages[i].sender && senderOrReceiver1 == allMessages[i].receiver))
        {
            sprintf(interpolatedString, "%i. From: %i, To: %i, %s\n", numMessages + 1, allMessages[i].sender, allMessages[i].receiver, allMessages[i].message);

            strcat(messages, interpolatedString);
            numMessages++;
        }
    }
    return messages;
}

// Sends the message history of the specified sender and receiver to the requestor
void historyCommand(char buf_list[], char clientInput[], int numberOfMessages, struct Message allMessages[], int i)
{
    strcpy(buf_list, "History\n");
    strtok(clientInput, " ");
    const int msgSenderOrReceiver = atoi(strtok(NULL, "\n"));

    strcat(buf_list, chatHistory(fd_A[i], msgSenderOrReceiver, numberOfMessages, allMessages));

    strcat(buf_list, "\nEND\n");
    send(fd_A[i], buf_list, strlen(buf_list), 0);
}

// Makes the client socket exit
void exitCommand(char buf_list[], int i)
{
    strcpy(buf_list, "Goodbye");
    send(fd_A[i], buf_list, strlen(buf_list), 0);
    close(fd_A[i]);
}

// Tells the client that it has entered an invalid command
void invalidCommand(char buf_list[], int i)
{
    strcpy(buf_list, "Please enter a valid command");
    send(fd_A[i], buf_list, strlen(buf_list), 0);
}

/*
Known Bugs
________________________
1. fuzzy matching
Ex. "msgg" will match with the "msg" command because the first 3 letters match
2. exit command error
Ex. select: Bad file descriptor
*/

int main(void)
{
    int sock_fd, new_fd;            // listen on sock_fd, new connection on new_fd
    struct sockaddr_in server_addr; // server address information
    struct sockaddr_in client_addr; // connector's address information
    socklen_t sin_size;
    int yes = 1;
    char buf[BUF_SIZE];
    char buf_list[BUF_SIZE];
    int ret;
    int i, j;
    char command1[] = "list";
    char command2[] = "msg";
    char command3[] = "history";
    char command4[] = "exit";
    const int STORED_MESSAGES = 100;
    struct Message allMessages[STORED_MESSAGES];
    int numberOfMessages = 0;

    if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("socket");
        exit(1);
    }

    if (setsockopt(sock_fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
    {
        perror("setsockopt");
        exit(1);
    }

    server_addr.sin_family = AF_INET;         // host byte order
    server_addr.sin_port = htons(MYPORT);     // short, network byte order
    server_addr.sin_addr.s_addr = INADDR_ANY; // automatically fill with my IP
    memset(server_addr.sin_zero, '\0', sizeof(server_addr.sin_zero));

    if (bind(sock_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1)
    {
        perror("bind");
        exit(1);
    }

    if (listen(sock_fd, BACKLOG) == -1)
    {
        perror("listen");
        exit(1);
    }

    printf("Listening on port %d\n", MYPORT);

    fd_set fdsr;
    int maxsock;
    struct timeval tv;

    conn_amount = 0;
    sin_size = sizeof(client_addr);
    maxsock = sock_fd;
    while (1)
    {
        // initialize file descriptor set
        FD_ZERO(&fdsr);
        FD_SET(sock_fd, &fdsr);

        // timeout setting
        tv.tv_sec = 30;
        tv.tv_usec = 0;

        // add active connection to fd set
        for (i = 0; i < BACKLOG; i++)
        {
            if (fd_A[i] != 0)
            {
                FD_SET(fd_A[i], &fdsr);
            }
        }

        ret = select(maxsock + 1, &fdsr, NULL, NULL, &tv);
        if (ret < 0)
        {
            perror("select");
            break;
        }
        else if (ret == 0)
        {
            continue;
        }

        // check every fd in the set
        for (i = 0; i < conn_amount; i++)
        {
            if (FD_ISSET(fd_A[i], &fdsr))
            {
                ret = recv(fd_A[i], buf, sizeof(buf), 0);
                if (ret <= 0)
                { // client close
                    printf("Client[%d] close\n", i);
                    close(fd_A[i]);
                    conn_amount--;
                    FD_CLR(fd_A[i], &fdsr);
                    fd_A[i] = 0;
                }
                else
                { // receive data
                    if (ret < BUF_SIZE)
                        memset(&buf[ret], '\0', 1);
                    printf("Client[%d] sent: %s\n", i, buf);

                    // copy the buffer input
                    char clientInput[strlen(buf)];
                    strncpy(clientInput, buf, strlen(buf));

                    // list
                    if (strncmp(strtok(buf, " "), command1, strlen(command1)) == 0)
                    {
                        listCommand(buf_list, &j, &i);
                    }

                    // msg
                    else if (strncmp(strtok(buf, " "), command2, strlen(command2)) == 0)
                    {
                        msgCommand(buf_list, clientInput, allMessages, &numberOfMessages, i);
                    }

                    // history
                    else if (strncmp(strtok(buf, " "), command3, strlen(command3)) == 0)
                    {
                        historyCommand(buf_list, clientInput, numberOfMessages, allMessages, i);
                    }

                    // exit
                    else if (strncmp(strtok(buf, " "), command4, strlen(command4)) == 0)
                    {
                        exitCommand(buf_list, i);
                    }

                    // in case the user doesn't enter a valid command
                    else
                    {
                        invalidCommand(buf_list, i);
                    }
                    memset(buf_list, 0, sizeof(*buf_list)); // Reset buf_list
                }
            }
        }

        // check whether a new connection comes
        if (FD_ISSET(sock_fd, &fdsr))
        {
            new_fd = accept(sock_fd, (struct sockaddr *)&client_addr, &sin_size);
            if (new_fd <= 0)
            {
                perror("accept");
                continue;
            }

            // add to fd queue
            if (conn_amount < BACKLOG)
            {
                fd_A[conn_amount++] = new_fd;
                printf("New connection client[%d] %s:%d\n", conn_amount,
                       inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
                if (new_fd > maxsock)
                    maxsock = new_fd;
            }
            else
            {
                printf("Max connections arrive, exit\n");
                send(new_fd, "bye", 4, 0);
                close(new_fd);
                break;
            }
        }
        showclient();
    }

    // close other connections
    for (i = 0; i < BACKLOG; i++)
    {
        if (fd_A[i] != 0)
        {
            close(fd_A[i]);
        }
    }

    exit(0);
}
